import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class App extends JFrame {
    private JButton btAddPessoaCidade;
    private JButton btVerificarDados;


    public App () {
        this.setTitle("Relatorio da Cidade");
        setBounds(500,250,400,160);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        btAddPessoaCidade = new JButton();
        btAddPessoaCidade.setText("Adicionar");
        btAddPessoaCidade.setBounds(10, 10, 150, 100);
        this.add(btAddPessoaCidade);

        btVerificarDados = new JButton();
        btVerificarDados.setText("Verificar");
        btVerificarDados.setBounds(225, 10, 150, 100);
        this.add(btVerificarDados);
        
        btAddPessoaCidade.addActionListener(new ActionListener () {
            public void actionPerformed(ActionEvent evt) {
                Cidade cidade = new Cidade();
                int verificaCodigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo da cidade:"));
                boolean existeCidade = false;
                for (Cidade i: Cidade.getListaCidade()) {
                    if (i.getCodigoC() == verificaCodigo) {
                    existeCidade = true;
                    cidade.setCidadeResidida(i.getNomeC());
                    JOptionPane.showMessageDialog(null, "Cidade já cadastrada!", "Resultado", JOptionPane.INFORMATION_MESSAGE);
                    cidade.setNomeP(JOptionPane.showInputDialog("Nome da pessoa:"));
                    String codigoP = (JOptionPane.showInputDialog("Codigo da Pessoa:"));
                    cidade.setCodigoP(Integer.parseInt(codigoP));
                    cidade.setSalario(Double.parseDouble(JOptionPane.showInputDialog("Salário:")));
                    Cidade.setPessoas(cidade);
                    //cidade.setNascimento(JOptionPane.showInputDialog("Data de Nascimento:"));
                    JOptionPane.showMessageDialog(null, "Cadastro da pessoa realizado com sucesso!", "Resultado", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                //Caso a cidade já tenha sido cadastrada: JOptionPane.showMessageDialog(null, "Cidade já cadastrada!", "Resultado", JOptionPane.INFORMATION_MESSAGE);

                if (existeCidade == false) {
                    cidade.setCodigoC(verificaCodigo);
                    cidade.setNomeC(JOptionPane.showInputDialog("Nome da cidade:"));
                    cidade.setUf((JOptionPane.showInputDialog("UF:")));
                    cidade.setCidades(cidade);
                    JOptionPane.showMessageDialog(null, "Cadastro da cidade realizado com sucesso!", "Resultado", JOptionPane.INFORMATION_MESSAGE);
                }

            }
        });
        
        btVerificarDados.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent evt) {
            int verificaOpcao = Integer.parseInt(JOptionPane.showInputDialog("O que voce deseja verificar?\n1- Cidade\n2- Pessoa"));
            if (verificaOpcao == 1) {
                for (Cidade i: Cidade.getListaCidade()) {
                    int numeroPessoas = 0;
                    int somaSalario = 0;
                    for (Pessoa j: Pessoa.getPessoas()) {
                        if (j.getCidadeResidida().equals(i.getNomeC())) {
                            numeroPessoas++;
                            somaSalario += j.getSalario();
                        }
                    }

                    int mediaSalarial = somaSalario / numeroPessoas;
                    JOptionPane.showInternalMessageDialog(null, "Cidade: " + i.getNomeC() +"\nCódigo: " + i.getCodigoC() + "\nUF: " + i.getUf() + "\nNúmero de pessoas registradas: " + numeroPessoas + "\nMédia Salarial: " + mediaSalarial, i.getNomeC(), JOptionPane.INFORMATION_MESSAGE);
                }
            }
            if (verificaOpcao == 2) {
                verificaOpcao = Integer.parseInt(JOptionPane.showInputDialog("Qual o código da pessoa?"));
                for (Pessoa i : Pessoa.getPessoas()) {
                    if (verificaOpcao == i.getCodigoP()) {
                        JOptionPane.showInternalMessageDialog(null, "Nome: " + i.getNomeP() + "\nCidade: " + i.getCidadeResidida() + "\nSalário: " + i.getSalario(), i.getNomeP(), JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        }
            
        });
    }

    public static void main(String[] args) throws Exception {
        App Interface = new App();
        Interface.setVisible(true);
    }
}
